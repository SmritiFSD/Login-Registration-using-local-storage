import React from 'react';
const Home = () => {
    return (
        <>
          <h1 className='texttitle'>Welcome To GeekSynergy</h1>  
          <h3>Name:Smritikana Ghosh</h3>
          <h3>React.js Task</h3>
        </>
    )
}
export default Home;