import React from 'react'

export default function CompanyInfo() {
    return (
        <div className='companyinfo'>
            <h2>Company: Geeksynergy Technologies Pvt Ltd</h2>
            <h2>Address: Sanjayanagar, Bengaluru-56</h2>
            <h2>Phone:XXXXXXXXX09</h2>
            <h2>Email: XXXXXX@gmail.com</h2>
        </div>
    )
}
